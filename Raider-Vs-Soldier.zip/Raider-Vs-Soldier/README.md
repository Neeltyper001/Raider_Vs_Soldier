# Guide about Raider Vs Soldier game

## Some checks before running this game
- This game is strictly compatible for PC and not for mobile or tablet devices.
- In order, to run this game you need to have java installed on your system. You can check as:
    - Open command prompt and type `java -version` and press enter.
    - If you get the version of java installed on your system then you are good to go.
    - If you get an error then you need to install java on your system.

## Installation steps for java
- Go to [java](https://www.java.com/en/download/) and download the latest version of java.
- Install java on your system.
- Now, you are good to go just click the jar file and enjoy the game.

## How to play the game
- The game is simple to play.
- You have to defend your base from the enemies that consist of countless waves of soldiers.
- Try to kill as many soldiers as you can.
- Try to defend your base as long as you can.

## Controls
- Use `W` to move up.
- Use `S` to move down.
- Use `A` to move left.
- Use `D` to move right.
- Use `J` to shoot.
- Use `Q` to run.

## License
- This game is licensed under [MIT License](https://github.com/Neeltyper001/Raider_Vs_Soldier/blob/feature/LICENSE)
- You can use this game for commercial purpose.
- You can modify this game.
- You can distribute this game.
- You can use the code of this game.
- You can use the assets of this game.
- You can use the images of this game.
- You can use the sounds of this game.
- You can use the music of this game.

## Credits
- Made by [Neelesh Joshi](https://github.com/Neeltyper001/)

## Last but not least
- If you like this game then please give a star to this repository.
- If you want to contribute to this game then you are most welcome.
- If you want to give any suggestions then please create an issue.

## Thank you for playing this game :)
